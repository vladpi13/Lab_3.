import java.util.Random;
import java.util.Scanner;

public class surface {
    public int angle, form, colour;

    //Инициализация
    public static surface surface_init(int a, int f, int col) {
        surface surface1 = new surface();
        surface1.angle = a;
        surface1.form = f;
        surface1.colour = col;

        return surface1;
    }
    //Ввод
    public static surface surface_vvod() {
        surface surface1 = new surface();
        System.out.print("Введите угол поворота поверхности: ");
        Scanner in = new Scanner(System.in);
        surface1.angle = in.nextInt();
        System.out.print("Введите форму поверхности (1 - конус, 2 - сфера, 3 - треугольник, 4 - квадрат): ");
        surface1.form = in.nextInt();
        do {
            System.out.print("Введите цвет поверхности (1 - оранжевый, 2 - красный, 3 - фиолетовый), 4 - желтый):");
            surface1.colour = in.nextInt();
        } while (surface1.colour < 1 && surface1.colour > 4);

        return surface1;
    }
    //Вывод
    public static void surface_vivod(surface surface1) {
        System.out.printf("\nДанные поверхности:\n\n Угол = %d\n", surface1.angle);
        if (surface1.form == 1)
            System.out.print(" Форма - конус\n");
        if (surface1.form == 2)
            System.out.print(" Форма - сфера\n");
        if (surface1.form == 3)
            System.out.print(" Форма - треугольник\n");
        if (surface1.form == 4)
            System.out.print(" Форма - квадрат\n");
        if (surface1.colour == 1)
            System.out.print(" Цвет - оранжевый\n");
        if (surface1.colour == 2)
            System.out.print(" Цвет - красный\n");
        if (surface1.colour == 3)
            System.out.print(" Цвет - фиолетовый\n");
        if (surface1.colour == 4)
            System.out.print(" Цвет - желтый\n");
    }
    //Изменение угла наклона поверхности
    public static int surface_rotate() {
        surface surface1 = new surface();
        Random random = new Random();
        surface1.angle = random.nextInt() % 15;
        return surface1.angle;
    }
}
