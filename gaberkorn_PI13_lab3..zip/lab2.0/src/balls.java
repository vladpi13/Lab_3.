import java.util.Random;
import java.util.Scanner;

public class balls {
    public int x, y;
    //Инициализация
    public static balls balls_init(int x, int y) {
        balls balls1 = new balls();
        balls1.x = 0;
        balls1.y = 0;
        return balls1;
    }

    //Ввод
    public static balls balls_vvod() {
        balls balls1 = new balls();
        Scanner in = new Scanner(System.in);
        System.out.println("Введите баллы первого студента: ");
        balls1.x = in.nextInt();
        System.out.println("Введите баллы второго студента: ");
        balls1.y = in.nextInt();

        return balls1;
    }

    //Вывод
    public static void balls_vivod(balls balls1) {
        System.out.printf("Первый студент = %d Второй студент = %d\n", balls1.x, balls1.y);
    }

    //Случайное изменение координат
    public static balls balls_coord() {
        balls balls1 = new balls();
        Random random = new Random();
        balls1.x = random.nextInt() % 7;
        balls1.y = random.nextInt() % 7;
        return balls1;
    }
}











