import java.io.IOException;
import java.util.Scanner;

public class lab2 {
    static int menu(){
        int i;
        do {
            System.out.print("  1) Сфера\n  2) Поверхность\n  3) Баллы\n  4) Рейтинг\n  5) Кнопка\n  0) Выход\n\n  Выберите действие: ");
            Scanner in = new Scanner(System.in);
            i = in.nextInt();
        } while (i < 0 && i > 5);
        return i;
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        sphere a = new sphere();
        surface plato = new surface();
        balls c = new balls();
        rating r = new rating();
        button1 b = new button1();
        Scanner in = new Scanner(System.in);

        int f = 1;
        int vib;
        do {
            switch (menu()) {
                case 0: //Выход
                    f = 0;
                    break;
                case 1: //Работа с шаром
                    do {
                        do {
                            System.out.print("\n  1 - Инициализация\n  2 - Ввод\n  3 - Печать данных\n  4 - Шаг\n  0 - Выход\n\n  Выберите действие: ");
                            vib = in.nextInt();
                        } while (vib < 0 && vib >4);
                        if (vib == 1)
                            a = sphere.sphere_init(2, 3, 1);
                        if (vib == 2)
                            a = sphere.sphere_vvod();
                        if (vib == 3)
                            sphere.sphere_vivod(a);
                        if (vib == 4)
                            a = sphere.sphere_move(a);
                        System.out.print("\nУспешно!");
                        Thread.sleep(1500);
                    } while (vib != 0);
                    break;
                case 2: //Работа с поверхностью
                    do {
                        do{
                            System.out.print("\n  1 - Инициализация\n  2 - Ввод\n  3 - Печать данных\n  4 - Вращать\n  0 - Выход\n\n  Выберите действие: ");
                            vib = in.nextInt();
                        } while (vib < 0 && vib >4);
                        if (vib == 1)
                            plato = surface.surface_init(1, 2, 3);
                        if (vib == 2)
                            plato = surface.surface_vvod();
                        if (vib == 3)
                            surface.surface_vivod(plato);
                        if (vib == 4)
                            plato.angle = surface.surface_rotate();

                        System.out.print("\nУспешно!");
                        Thread.sleep(1500);
                    } while (vib != 0);
                    break;
                case 3: //Работа с баллами
                    do {
                        do {
                            System.out.print("\n  1 - Инициализация\n  2 - Ввод\n  3 - Вывод баллов\n  4 - Случайные баллы\n  0 - Выход\n\n  Выберите действие: ");
                            vib = in.nextInt();
                        } while (vib < 0 && vib >4);
                        if (vib == 1)
                            c = balls.balls_init(1, 1);
                        if (vib == 2)
                            c = balls.balls_vvod();
                        if (vib == 3) {
                            System.out.print("\nБаллы:\n\n");
                            balls.balls_vivod(c);
                        }
                        if (vib == 4)
                            c = balls.balls_coord();
                        System.out.print("\nУспешно!");
                        Thread.sleep(1500);
                    } while (vib != 0);
                    break;
                case 4: //Работа с рейтингом
                    do {
                        do {
                            System.out.print("\n  1 - Инициализация\n  2 - Вывод рейтинга\n  3 - Прибавить один балл к рейтингу\n  0 - Выход\n\n  Выберите действие: ");
                            vib = in.nextInt();
                        } while (vib < 0 && vib >3);
                        //while (getchar() != '\n');
                        if (vib == 1) {
                            balls[] mas = new balls[5];
                            for (int i = 0; i < 5; i++)
                                mas[i] = balls.balls_coord();
                            r = rating.rat_init(0, mas);
                        }
                        if (vib == 2) {
                            rating.rat_vivod(r);
                            //_getch();
                            in.nextInt();
                        }
                        if (vib == 3)
                            r.i = rating.rat_plus(r);
                        System.out.print("\nУспешно!");
                        Thread.sleep(1500);
                    } while (vib != 0);
                    break;
                case 5: //Работа с кнопкой
                    do {
                        do{
                            System.out.print("\n  1 - Инициализация\n  2 - Вывод рейтинга\n  3 - Прибавить один балл к рейтингу\n  0 - Выход\n\n  Выберите действие: ");
                            vib = in.nextInt();
                        } while (vib < 0 && vib >3);
                        if (vib == 1)
                            b = button1.button_init(false);
                        if (vib == 2)
                            button1.button_vivod(b);
                        if (vib == 3)
                            b = button1.button_press(b);
                        System.out.print("\nУспешно!");
                        Thread.sleep(1500);
                    } while (vib != 0);
                    break;
            }
        } while (f == 1);
    }

}
