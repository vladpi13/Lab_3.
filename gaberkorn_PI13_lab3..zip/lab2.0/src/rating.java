public class rating {
    public int i;
    public balls[] c = new balls[5];

    //Инициализация
    public static rating rat_init(int i, balls mas_c[]) {
        rating rat1 = new rating();
        int j;
        rat1.i = i;
        for (j = 0; j < 5; j++)
            rat1.c[j] = mas_c[j];
        return rat1;
    }
    //Вывод
    public static void rat_vivod(rating rat1) {
        int j;
        System.out.printf("\nРейтинг: %d\n", rat1.i);
        System.out.printf("\nБаллы студентов:\n\n");
        for (j = 0; j < 5; j++)
            balls.balls_vivod(rat1.c[j]);
    }
    //Увеличение значения рейтинга
    public static int rat_plus(rating rat1) {
        rat1.i++;
        return rat1.i;
    }
}
