public class button1 {
    public boolean f;

    //Инициализация
    public static button1 button_init(boolean f) {
        button1 but1 = new button1();
        but1.f = f;
        return but1;
    }
    //Вывод
    public static void button_vivod(button1 but1) {
        if (!but1.f)
            System.out.print("\n\nКнопка не нажата\n");
        else
            System.out.print("\n\nКнопка нажата\n");
    }
    //Нажать на кнопку
    public static button1 button_press(button1 but1) {
        but1.f = !but1.f;
        return but1;
    }
}
