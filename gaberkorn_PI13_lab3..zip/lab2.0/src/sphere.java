import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class sphere {
    public int x, y, colour;

    //Инициализация
    public static sphere sphere_init(int x, int y, int col) {
        sphere sphere1 = new sphere();
        sphere1.x = x;
        sphere1.y = y;
        sphere1.colour = col;

        return sphere1;
    }
    //Ввод
    public static sphere sphere_vvod() {
        sphere sphere1 = new sphere();
        Scanner in = new Scanner(System.in);
        System.out.printf("Введите x-координату сферы: ");
        sphere1.x = in.nextInt();
        System.out.print("Введите y-координату сферы: ");
        sphere1.y = in.nextInt();
        System.out.print("Введите цвет сферы (1 - белый, 2 - красный, 3 - синий): ");
        sphere1.colour = in.nextInt();

        return sphere1;
    }
    //Вывод
    public static void sphere_vivod(sphere sphere1) {
        System.out.printf("\nДанные сферы:\n\n X = %d\n Y = %d", sphere1.x, sphere1.y);
        if (sphere1.colour == 1)
            System.out.print("\n Цвет - белый\n");
        if (sphere1.colour == 2)
            System.out.print("\n Цвет - красный\n");
        if (sphere1.colour == 3)
            System.out.print("\n Цвет - синий\n");
    }
    //Сделать шаг
    public static sphere sphere_move(sphere sphere1) throws IOException {
        System.out.print("Нажмите \n 'D', чтобы увеличить значение x \n 'A', чтобы уменьшить значение x\n 'W', чтобы увеличить значение y\n 'S', чтобы уменьшить значение y\n");
        InputStreamReader scanner = new InputStreamReader(System.in);
        char key = (char)scanner.read();
        if (key == 'a')
            sphere1.x--;
        if (key == 'd')
            sphere1.x++;
        if (key == 'w')
            sphere1.y++;
        if (key == 's')
            sphere1.y--;

        return sphere1;
    }
}
